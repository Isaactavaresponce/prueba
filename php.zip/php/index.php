<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./assets/styles/style.css">
    <title> Catalogo </title>
</head>



<body>

    <ul class="choose-color">
        <li><a href="./login/login.php"> Login</a></li>
        <li><a href="./registro/registro.php"> Registrarse </a></li>
        <li><a href="./index.php"> Menu </a></li>

    </ul>


    <div class="menuContainer">


        <!-- Tacos -->
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>

        <!-- Tortas -->
        <div class="product" style="background: url('./assets/images/productos/burrito.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>

        <!-- Tortas -->
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>

        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>


        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>

        
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>

        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>
        <div class="product" style="background: url('./assets/images/productos/taco.jpg')">
            <div class="productDescription">

                <h2> TACOS </h2>
                <p> Pasele pasele werita tenemos taquitos de pastor y de bistec. </p>
                <button class="btn"> Comprar $35 </button>

            </div>
        </div>



    </div>


</body>
</html>