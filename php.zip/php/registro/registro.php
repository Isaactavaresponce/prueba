<?php
include "../Conexion.php"; //Se incluye el archivo coneccion php
$db = connects(); //variable que devuelve la coneccion
$query = $db->query("select * from paises"); //variable que llama a db que esta haciendo una seleccion a paises
$countries = array(); //variable que se identifica como un archivo json
while ($r = $query->fetch_object()) { //r es lo que devuelve el query, y se incerta dentro del archivo json
  $countries[] = $r;
}
;

$query = $db->query("select * from estados"); //variable que llama a db que esta haciendo una seleccion a paises
$estado = array(); //variable que se identifica como un archivo json
while ($r = $query->fetch_object()) { //r es lo que devuelve el query, y se incerta dentro del archivo json
  $estado[] = $r;
}
;

$query = $db->query("select * from municipios"); //variable que llama a db que esta haciendo una seleccion a paises
$municipio = array(); //variable que se identifica como un archivo json
while ($r = $query->fetch_object()) { //r es lo que devuelve el query, y se incerta dentro del archivo json
  $municipio[] = $r;
}
;

?>



<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Registro</title>
  <!--este php hace que se actualice el css-->
  <link rel="stylesheet" href="../assets/styles/styles-registro.css?uuid=<?php echo uniqid(); ?>" />
</head>

<body>

  <ul class="cabezera">
    <li class="active"><a href="../index.php">Inicio</a></li>
    <li><a href="../login/login.php">login </a></li>
  </ul>

  <!--Formulario de Login y registro-->
  <div class="contenedor__login-register">
    <!--Register-->
    <form method="post" class="formulario__register">
      <!--Inicio del formulario-->
      <h2>Regístrarse</h2>
      <!--minleingth es el minimo de caracteres, maxlength es el numero de caracteres maxlength el numero de caracteres maximos-->
      <input type="text" placeholder="Apellido paterno" name="apPaterno" minlength="1" maxlength="20" required />
      <input type="text" name="apMaterno" placeholder="Apellido materno" minlength="1" maxlength="20" required />
      <input type="text" name="nombre" placeholder="Nombres" minlength="1" maxlength="30" required />
      <!--Fieldset es un cuadrito donde se ingresa la informacion-->
      <!--Cada input es una caja de texto vacia que permite ingresar datos-->
      <fieldset>
        <label for="fecha">Fecha de nacimiento</label>
        <input name="fechaNacimiento" id="fecha" type="date" required />
      </fieldset>
      <select id="continente_id" name="continente_id" required>

        <option value="">--Selecciona un pais--</option>
        <?php foreach ($countries as $c): ?>
          <option value="<?php echo $c->id; ?>"><?php echo $c->nombre; ?></option>
        <?php endforeach; ?>
      </select>
      <select id="pais_id" name="pais_id" required>
        <option>--Selecciona un estado</option>
        <?php foreach ($estado as $e): ?>
          <option value="<?php echo $e->id; ?>"><?php echo $e->estado; ?></option>
        <?php endforeach; ?>
      </select>
      <select id="ciudad_id" name="ciudad_id" required>
        <option>--Selecciona un municipio--</option>
        <?php foreach ($municipio as $m): ?>
          <option value="<?php echo $m->id; ?>"><?php echo $m->municipio; ?></option>
        <?php endforeach; ?>
      </select>
      <input type="tel" name="telefono" placeholder="Numero" minlength="10" maxlength="10" required />
      <input type="email" placeholder="Correo elctronico" name="email" required />
      <input name="password" type="password" placeholder="Contraseña" minlength="10" maxlength="30" required />
      <input class="boton" type="submit" name="registrar" value="registrar">
    </form>
    <?php
    include('registrar.php');
    ?>
  </div>
  </div>
</body>

</html>