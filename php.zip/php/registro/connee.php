<?php

$conex = mysqli_connect("localhost","root","","sistema",3307); 

?>