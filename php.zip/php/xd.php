<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema";

$conn = mysqli_connect($servername, $username, $password, $dbname,3307);

$sql = "SELECT * FROM users";
$resultado = mysqli_query($conn, $sql);

while($fila = mysqli_fetch_assoc($resultado)) {
    echo "Nombre: " . $fila["nombre"] . "<br>";
    echo "Email: " . $fila["email"] . "<br>";
    // y así sucesivamente para cada campo que quieras mostrar
}

mysqli_close($conn);

?>