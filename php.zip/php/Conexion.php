<?php
// simple conexion a la base de datos
function connects(){
	return new mysqli("localhost","root","","sistema",3307);
};


?>